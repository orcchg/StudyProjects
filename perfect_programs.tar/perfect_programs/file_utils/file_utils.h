/*! @file file_utils.h
 *  @brief Utilities to work with file system.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include <vector>
#include <string>

#ifndef SRC_LIB_COMMON_FILE_UTILS_H_
#define SRC_LIB_COMMON_FILE_UTILS_H_


bool ListFiles(const std::string &dir,
               std::vector<std::string> *files);

bool FileExists(const std::string &file);

#endif  // SRC_LIB_COMMON_FILE_UTILS_H_

