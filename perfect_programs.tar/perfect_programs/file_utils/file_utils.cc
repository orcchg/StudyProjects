/*! @file file_utils.cc
 *  @brief Implementation of utility functions to work with file system.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include <assert.h>
#include <dirent.h>
#include <sys/stat.h>
#include "include/common.h"
#include "src/lib/common/file_utils.h"

bool ListFiles(const std::string &dir,
               std::vector<std::string> *files) {
  assert(files !=static_cast<void *>(nullptr));
  DIR *dp;
  struct dirent *dirp;
  if ((dp  = opendir(dir.c_str())) == nullptr) {
    return false;
  }
  while ((dirp = readdir(dp)) != nullptr) {
      files->push_back(std::string(dirp->d_name));
  }
  closedir(dp);
  return true;
}

bool FileExists(const std::string &file) {
  struct stat ss;
  return stat(file.c_str(), &ss) == 0;
}

