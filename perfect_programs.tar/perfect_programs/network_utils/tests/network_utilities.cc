/*! @file network_utilities.cc
 *  @brief Tests for lib/common/network_utilities.*
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "src/lib/common/network_utilities.h"
#include <net/if.h>
#include "include/common.h"
#include "tests/google/gtest/gtest.h"

std::string safe_default_iface() {
  auto realIfaceFd = popen(
      "ip route show default | grep default | cut -d\" \" -f5", "r");
  char *realIface = nullptr;
  size_t realIfaceLength;
  assert(getline(&realIface, &realIfaceLength, realIfaceFd) > -1);
  *strstr(realIface, "\n") = 0;
  std::string ret(realIface);
  free(realIface);
  pclose(realIfaceFd);
  return ret;
}

std::string safe_addr(const std::string &ifaceName) {
  std::string cmd("ifconfig | grep ");
  cmd += ifaceName;
  cmd += " -A1 | grep \"inet addr\" | cut -c 21- | cut -d\" \" -f1";
  auto realAddrFd = popen(cmd.c_str(), "r");
  char *realAddr = nullptr;
  size_t realAddrLength;
  assert(getline(&realAddr, &realAddrLength, realAddrFd) > 0);
  *strstr(realAddr, "\n") = 0;
  std::string ret(realAddr);
  free(realAddr);
  pclose(realAddrFd);
  return ret;
}

TEST(get_default_network_iface, get_default_network_iface) {
  IpResolver::instance().reset();
  ASSERT_STREQ(safe_default_iface().c_str(),
               IpResolver::instance().iface().c_str());
}

TEST(get_ip_addr, get_ip_addr) {
  auto ifaces = if_nameindex();
  for (int i = 0; ifaces[i].if_name != nullptr; i++) {
    IpResolver::instance().set_interface(ifaces[i].if_name);
    ASSERT_STREQ(safe_addr(ifaces[i].if_name).c_str(),
                 IpResolver::instance().ip().c_str());
  }
  if_freenameindex(ifaces);
}

TEST(get_ip_addr, usb) {
  auto ifaces = if_nameindex();
  for (int i = 0; ifaces[i].if_name != nullptr; i++) {
    if (!strcmp(ifaces[i].if_name, "samsung_device")) {
      // samsung_device interface found, assuming Tizen
      IpResolver::instance().set_interface(ifaces[i].if_name);
      ASSERT_STREQ("192.168.129.4",
                   IpResolver::instance().ip().c_str());
    }
  }
  if_freenameindex(ifaces);
}

TEST(get_ip_addr_default, get_ip_addr_default) {
  IpResolver::instance().reset();
  ASSERT_STREQ(safe_addr(safe_default_iface()).c_str(),
               IpResolver::instance().ip().c_str());
}

#include "tests/google/src/gtest_main.cc"

