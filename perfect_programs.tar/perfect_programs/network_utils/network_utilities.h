/*! @file network_utilities.h
 *  @brief Various network utility functions.
 *  @author Moiseenko Andrey <moiseenko.a@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#ifndef SRC_LIB_COMMON_NETWORK_UTILITIES_H_
#define SRC_LIB_COMMON_NETWORK_UTILITIES_H_
#include <string>
#include "include/common.h"

class IpResolver : public Singleton<IpResolver> {
  friend class Singleton<IpResolver>;
 public:
  std::string ip();
  std::string set_interface(const std::string& i_iface);
  const std::string& iface();
  void reset();
 protected:
  IpResolver();
 private:
  std::string iface_;
  std::string ip_;
};

#endif  // SRC_LIB_COMMON_NETWORK_UTILITIES_H_

