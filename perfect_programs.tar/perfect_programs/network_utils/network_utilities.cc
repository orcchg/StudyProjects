/*! @file network_utilities.cc
 *  @brief Various network utility functions.
 *  @author Moiseenko Andrey <moiseenko.a@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "src/lib/common/network_utilities.h"
#include <net/route.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <assert.h>
#include <Eina.h>
#include "include/common.h"

#define LOCAL_ADDR "127.0.0.1"
/*
/// @brief Returns the name of the network interface the default route
/// belongs to.
static std::string get_default_network_iface();

/// @brief Returns the network address of the specified interface.
static std::string get_ip_addr();

/// @brief Returns the network address of the default interface.
static std::string get_ip_addr_default();
*/
static std::string get_default_network_iface() {
  std::string ifaceRet;
  auto routeFd = fopen("/proc/net/route", "r");
  assert(routeFd != nullptr);
  char *line = nullptr;
  size_t lineLength;
  assert(getline(&line, &lineLength, routeFd) > -1);
  free(line);
  line = nullptr;

  while (getline(&line, &lineLength, routeFd) > -1) {
    unsigned flags, other;
    char ifaceName[128];
    if (sscanf(line, "%127s%X%X%X", ifaceName, &other, &other, &flags) != 4) {
      break;
    }
    free(line);
    line = nullptr;
    if ((flags & RTF_GATEWAY) && (flags & RTF_UP)) {
      ifaceRet = ifaceName;
      break;
    }
  }
  fclose(routeFd);
  EINA_LOG_INFO("Taking \"%s\" as the default network interface",
               ifaceRet.c_str());
  return ifaceRet;
}

static std::string get_ip_addr(const std::string &iface) {
  std::string ip(LOCAL_ADDR);

  if (iface == "") {
    EINA_LOG_WARN("Network interface was not defined, falling back to %s",
                  ip.c_str());
    return ip;
  }

  struct ifaddrs* ifAddrStruct = nullptr;
  getifaddrs(&ifAddrStruct);

  for (auto ifa = ifAddrStruct; ifa != nullptr; ifa = ifa->ifa_next) {
      if (ifa ->ifa_addr != nullptr &&
          ifa ->ifa_addr->sa_family == AF_INET) {  // check it to be IPv4
        auto tmpAddrPtr = &(reinterpret_cast<struct sockaddr_in *>(
            ifa->ifa_addr)->sin_addr);
        char addressBuffer[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
        if (iface == ifa->ifa_name) {
          ip = addressBuffer;
          EINA_LOG_INFO("Taking %s as the network address", ip.c_str());
          break;
        }
      }
  }
  if (ifAddrStruct != nullptr) {
    freeifaddrs(ifAddrStruct);
  }

  if (ip == LOCAL_ADDR) {
    EINA_LOG_WARN("Couldn't find the network address, falling back to %s",
                  ip.c_str());
  }
  return ip;
}

std::string IpResolver::ip() {
  return ip_;
}

std::string IpResolver::set_interface(const std::string &i_iface) {
  std::string tmp(iface_);
  iface_ = i_iface;
  ip_ = get_ip_addr(iface_);
  return tmp;
}

const std::string& IpResolver::iface() {
  return iface_;
}

void IpResolver::reset() {
  iface_ = get_default_network_iface();
  ip_ = get_ip_addr(iface_);
}
IpResolver::IpResolver()
: iface_(get_default_network_iface())
, ip_(get_ip_addr(iface_)) {}



