/*! @file dns_resolve.h
 *  @brief DNS resolver declaration.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */


#include <string>
#include "include/common.h"

#ifndef SRC_LIB_P2PPROTO_DNS_RESOLVE_H_
#define SRC_LIB_P2PPROTO_DNS_RESOLVE_H_

namespace Network {

std::string Resolve(const std::string &addr);
}

#endif  // SRC_LIB_P2PPROTO_DNS_RESOLVE_H_

