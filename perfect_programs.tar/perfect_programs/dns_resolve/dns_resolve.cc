/*! @file dns_resolve.cc
 *  @brief DNS resolver implementation.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */


#include "src/lib/p2pproto/dns_resolve.h"
#include <netdb.h>
#include <arpa/inet.h>
#include "include/common.h"

namespace Network {

/// @brief Perform DNS lookup of the specified address.
/// @param addr The address to resolve.
/// @note addr can be either an IP address or a domain name.
/// @return The resolved IP address or "" if failed.
std::string Resolve(const std::string &addr) {
  addrinfo *resolvedAddresses;
  int resolvRes = getaddrinfo(addr.c_str(), nullptr, nullptr,
                              &resolvedAddresses);
  if (resolvRes != 0) {
    return "";
  }
  std::string resolvedAddress(inet_ntoa(
      ((struct sockaddr_in *)resolvedAddresses->ai_addr)->sin_addr));
  freeaddrinfo(resolvedAddresses);
  return resolvedAddress;
}
}

