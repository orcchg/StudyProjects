/*! @file death_handler.h
 *  @brief A handler for segfault backtrace.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#ifndef INCLUDE_DEATH_HANDLER_H_
#define INCLUDE_DEATH_HANDLER_H_

#include <string>

namespace Conference {

class DeathHandler {
 public:
  DeathHandler();
 private:
  static std::string Demangle(const std::string &symbol);
  static void SignalHandler(int sig, void *info,
                            void *secret);
};

} /* namespace Conference */
#endif  // INCLUDE_DEATH_HANDLER_H_

