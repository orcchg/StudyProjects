/*! @file death_handler.cc
 *  @brief A handler for segfault backtrace.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "include/death_handler.h"
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <execinfo.h>
#include <cxxabi.h>
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>

namespace Conference {

DeathHandler::DeathHandler() {
  struct sigaction sa;
  sa.sa_handler = (__sighandler_t)SignalHandler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_RESTART | SA_SIGINFO;
  sigaction(SIGSEGV, &sa, NULL);
}

std::string DeathHandler::Demangle(const std::string &symbol) {
  size_t size;
  int status;
  char temp[256];
  char* demangled;
  // first, try to demangle a c++ name
  if (1 == sscanf(symbol.c_str(),  // NOLINT(runtime/printf)
                  "%*[^(]%*[^_]%127[^)+]", temp)) {
    if ((demangled = abi::__cxa_demangle(temp, NULL, &size, &status))) {
      std::string result(demangled);
      free(demangled);
      return result;
    }
  }
  // if that didn't work, try to get a regular c symbol
  if (1 == sscanf(symbol.c_str(), "%127s", temp)) {  // NOLINT(runtime/printf)
    std::string line(temp);
    auto left = line.find_last_of('(') + 1;
    auto right = line.find_last_of('+');
    if (right == std::string::npos) {
      right = line.find_last_of(')');
    }
    return line.substr(left, right - left);
  }

  // if all else fails, just return the symbol
  return symbol;
}

void DeathHandler::SignalHandler(int sig __attribute__((unused)),
                                    void *info __attribute__((unused)),
                                    void *secret) {
  void *trace[16];
  char **messages;
  ucontext_t *uc = reinterpret_cast<ucontext_t *>(secret);

  if (dup2(2, 1) == -1) {  // redirect stdout to stderr
    fprintf(stderr, "Failed to redirect stdout to stderr\n");
  }
  fprintf(stderr, "\033[31;1mSegmentation fault\033[0m \033[33;1m(%i)\033[0m\n",
          getpid());

  char name_buf[1024];
  name_buf[readlink("/proc/self/exe", name_buf, sizeof(name_buf) - 1)] = 0;

  auto trace_size = backtrace(trace, 16);
  // overwrite sigaction with caller's address
#if defined(TIZEN)
  trace[1] = reinterpret_cast<void *>(uc->uc_mcontext.arm_pc);
#else
  trace[1] = reinterpret_cast<void *>(uc->uc_mcontext.gregs[REG_EIP]);
#endif
  messages = backtrace_symbols(trace, trace_size);
  printf("\nStack trace:\n");

  // skip first stack frame (points here)
  for (auto i = 1; i < trace_size - 2; i++) {
    if (i == 2 && !strcmp(messages[1], messages[2])) continue;
    printf("\033[34;1m[%s]\033[0m \033[33;1m(%i)\033[0m\n",
           Demangle(messages[i]).c_str(), getpid());

    char syscmd[1280];
    Dl_info dlinf;
    if (dladdr(trace[i], &dlinf) == 0 || !strcmp(name_buf, dlinf.dli_fname)) {
      snprintf(syscmd, sizeof(syscmd), "addr2line %p -e %s",
               trace[i], name_buf);
    } else {
      snprintf(syscmd, sizeof(syscmd), "addr2line %p -e %s",
               reinterpret_cast<void *>(reinterpret_cast<char *>(trace[i]) -
                 reinterpret_cast<char *>(dlinf.dli_fbase)),
               dlinf.dli_fname);
    }
    auto lineFd = popen(syscmd, "r");
    if (lineFd == NULL) {
      exit(EXIT_FAILURE);
    }
    char *line = NULL;
    size_t lineSize;
    if (getline(&line, &lineSize, lineFd) == -1) {
      exit(EXIT_FAILURE);
    }
    // Remove relative path root
    auto pathCutPos = strstr(line, "../");
    if (pathCutPos != NULL) {
      pathCutPos += 3;
      while (!strncmp(pathCutPos, "../", 3)) {
        pathCutPos += 3;
      }
      lineSize = lineSize - (pathCutPos - line);
      memmove(line, pathCutPos, lineSize);
    }
    // Mark line number
    auto numberPos = strstr(line, ":");
    if (numberPos != NULL) {
      char lineNumber[lineSize - (numberPos - line)];  // NOLINT(runtime/arrays)
      memcpy(lineNumber, numberPos, sizeof(lineNumber));
      line = reinterpret_cast<char *>(
          realloc(line, lineSize + strlen("\033[32;1m\033[0m")));
      sprintf(line + lineSize - sizeof(lineNumber),  // NOLINT(runtime/printf)
              "\033[32;1m%s\033[0m", lineNumber);
      lineSize += strlen("\033[32;1m\033[0m");
    }
    auto newLinePos = strstr(line, "\n");
    if (newLinePos != NULL) {
      *newLinePos = ' ';
    }
    printf("%s\033[33;1m(%i)\033[0m\n", line, getpid());
    free(line);
    pclose(lineFd);
  }

  exit(EXIT_FAILURE);
}

} /* namespace Conference */

