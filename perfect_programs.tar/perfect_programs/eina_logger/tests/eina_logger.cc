/*! @file eina_logger.cc
 *  @brief Tests for EinaLogger.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include <unistd.h>
#include <fstream>
#include "include/eina_logger.h"
#include "tests/google/gtest/gtest.h"

enum EinaLogLevels {
  kEinaLogLevelCrt,
  kEinaLogLevelErr,
  kEinaLogLevelWrn,
  kEinaLogLevelInf,
  kEinaLogLevelDbg
};

class LogTester
: public EinaLogger {
 public:
  LogTester() : EinaLogger("LogTester", EINA_COLOR_BLUE) {
  }

  LogTester(LogTester &other) : EinaLogger(other) {
  }

  void Log(const char *message, EinaLogLevels level) {
    switch (level) {
      case kEinaLogLevelCrt:
        CRT("%s", message);
        break;
      case kEinaLogLevelErr:
        ERR("%s", message);
        break;
      case kEinaLogLevelWrn:
        WRN("%s", message);
        break;
      case kEinaLogLevelInf:
        INF("%s", message);
        break;
      case kEinaLogLevelDbg:
        DBG("%s", message);
        break;
      default:
        break;
    }
  }
};

TEST(EinaLogger, SameClasses) {
  LogTester l1;
  LogTester l2;
  ASSERT_NE(l1.log_domain(), l2.log_domain());
}

TEST(EinaLogger, Copy) {
  LogTester l1;
  LogTester l2(l1);
  ASSERT_NE(l1.log_domain(), l2.log_domain());
}

TEST(EinaLogger, Logging) {
  eina_log_level_set(5);
  fpos_t pos;
  fgetpos(stderr, &pos);
  int fderr = dup(fileno(stderr));
  if (freopen("log", "w", stderr) == nullptr) assert(false);
  {
    LogTester lt;
    lt.Log("messageDBG", kEinaLogLevelDbg);
    lt.Log("messageINF", kEinaLogLevelInf);
    lt.Log("messageWRN", kEinaLogLevelWrn);
    lt.Log("messageERR", kEinaLogLevelErr);
    lt.Log("messageCRT", kEinaLogLevelCrt);
  }
  fflush(stderr);
  dup2(fderr, fileno(stderr));
  close(fderr);
  clearerr(stderr);
  fsetpos(stderr, &pos);
  std::ifstream fr("log", std::ifstream::in);
  std::string log((std::istreambuf_iterator<char>(fr)),
                   std::istreambuf_iterator<char>());
  ASSERT_NE(log.find(__FILE__), std::string::npos);
  ASSERT_NE(log.find("messageDBG"), std::string::npos);
  ASSERT_NE(log.find("messageINF"), std::string::npos);
  ASSERT_NE(log.find("messageWRN"), std::string::npos);
  ASSERT_NE(log.find("messageERR"), std::string::npos);
  ASSERT_NE(log.find("messageCRT"), std::string::npos);
  ASSERT_NE(log.find("Initialize()"), std::string::npos);
  ASSERT_NE(log.find("Deinitialize()"), std::string::npos);
  ASSERT_NE(log.find("LogTester"), std::string::npos);
  ASSERT_NE(log.find(COMMON_DOMAIN), std::string::npos);
  remove("log");
  eina_log_level_set(1);
}

#include "tests/google/src/gtest_main.cc"

