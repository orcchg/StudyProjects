/*! @file eina_logger.cc
 *  @brief EinaLogger implementation.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "include/eina_logger.h"
#include <cxxabi.h>

void EinaLogger::Initialize() {
  Deinitialize();
  eina_init();
  eina_log_threads_enable();
  int len = strlen(COMMON_DOMAIN) + strlen(domain_str_.c_str()) + 1;
  char *fullDomain = new char[len];
  snprintf(fullDomain, len, "%s%s", COMMON_DOMAIN, domain_str_.c_str());
  log_domain_ = eina_log_domain_register(fullDomain, color_.c_str());
  if (log_domain_ < 0) {
    int message_len = len + 128;
    char *message = new char[message_len];
    snprintf(message, message_len, "%s%s%s",
            "could not register ", fullDomain, " log domain.");
    EINA_LOG_DOM_ERR(EINA_LOG_DOMAIN_GLOBAL, "%s", message);
    log_domain_ = EINA_LOG_DOMAIN_GLOBAL;
  } else {
    if (!suppressLoggingInitialized_) {
      DBG("Logging initialized with domain %i.",
          log_domain_);
    }
  }
  delete[] fullDomain;
}

void EinaLogger::Deinitialize() {
  if (log_domain_ != unintialized_log_domain_ &&
      log_domain_ != EINA_LOG_DOMAIN_GLOBAL) {
    if (!suppressLoggingInitialized_) {
      DBG("eina_log_domain_unregister(%i)", log_domain_);
    }
    eina_log_domain_unregister(log_domain_);
    log_domain_ = unintialized_log_domain_;
  }
}

int EinaLogger::log_domain() const {
  assert(log_domain_ != unintialized_log_domain_);
  return log_domain_;
}

std::string EinaLogger::domain_str() const {
  return domain_str_;
}

void EinaLogger::set_domain_str(const std::string &value) {
  domain_str_ = value;
  Initialize();
}

std::string EinaLogger::color() const {
  return color_;
}

void EinaLogger::set_color(const std::string &value) {
  color_ = value;
  Initialize();
}

std::string EinaLogger::Demangle(const std::string &symbol) {
  size_t size;
  int status;
  char *demangled;
  if ((demangled = abi::__cxa_demangle(symbol.c_str(), NULL, &size, &status))) {
    std::string result(demangled);
    free(demangled);
    return result;
  }

  return symbol;
}

