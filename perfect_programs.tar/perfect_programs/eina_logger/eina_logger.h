/*! @file eina_logger.h
 *  @brief Logging with Eina.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 *
 *  @description Usage
 *  #include "include/eina_logger.h"
 *
 *  class Foo : public EinaLogger {
 *   public:
 *    Foo() : EinaLogger("foo job", EINA_COLOR_ORANGE) {
 *      DBG("entered");
 *      INF("almost");
 *      WRN("finished");
 *      ERR("failed");
 *    }
 *  };
 */



#ifndef INCLUDE_EINA_LOGGER_H_
#define INCLUDE_EINA_LOGGER_H_

#include <assert.h>
#include <Eina.h>
#include <string>
#include "include/common.h"

#define DBG(...) EINA_LOG_DOM_DBG(this->log_domain(), __VA_ARGS__)
#define INF(...) EINA_LOG_DOM_INFO(this->log_domain(), __VA_ARGS__)
#define WRN(...) EINA_LOG_DOM_WARN(this->log_domain(), __VA_ARGS__)
#define ERR(...) EINA_LOG_DOM_ERR(this->log_domain(), __VA_ARGS__)
#define CRT(...) EINA_LOG_DOM_CRIT(this->log_domain(), __VA_ARGS__)

#define DBGI(x, ...) EINA_LOG_DOM_DBG((x)->log_domain(), __VA_ARGS__)
#define INFI(x, ...) EINA_LOG_DOM_INFO((x)->log_domain(), __VA_ARGS__)
#define WRNI(x, ...) EINA_LOG_DOM_WARN((x)->log_domain(), __VA_ARGS__)
#define ERRI(x, ...) EINA_LOG_DOM_ERR((x)->log_domain(), __VA_ARGS__)
#define CRTI(x, ...) EINA_LOG_DOM_CRIT((x)->log_domain(), __VA_ARGS__)

#define DBGC(x, ...) EINA_LOG_DOM_DBG(x::log_domain(), __VA_ARGS__)
#define INFC(x, ...) EINA_LOG_DOM_INFO(x::log_domain(), __VA_ARGS__)
#define WRNC(x, ...) EINA_LOG_DOM_WARN(x::log_domain(), __VA_ARGS__)
#define ERRC(x, ...) EINA_LOG_DOM_ERR(x::log_domain(), __VA_ARGS__)
#define CRTC(x, ...) EINA_LOG_DOM_CRIT(x::log_domain(), __VA_ARGS__)
#define COMMON_DOMAIN "vconf-"

#define GSTELEMENT_LOG_COLOR EINA_COLOR_ORANGE
#define DBUSDUPLEX_LOG_COLOR EINA_COLOR_YELLOW
#define EINA_LOGGER_COLOR EINA_COLOR_WHITE
#define GST_CREATOR_COLOR EINA_COLOR_RED
#define INTROSPECTION_BUILDER_COLOR EINA_COLOR_CYAN
#define VCONFGUI_LOG_COLOR EINA_COLOR_GREEN
#define NICE_CONNECTION_COLOR EINA_COLOR_LIGHTBLUE
#define VCONFERENCE_COLOR EINA_COLOR_LIGHTRED
#define BASE_STREAM_COLOR EINA_COLOR_CYAN
#define MASTER_LOG_COLOR EINA_COLOR_RED
#define FARSTREAM_SESSION_LOG_COLOR EINA_COLOR_YELLOW
#define SEMAPHORE_LOG_COLOR EINA_COLOR_WHITE
#define ICONFERENCE_LOG_COLOR EINA_COLOR_LIGHTBLUE
#define TCP_THREAD_MANAGER_COLOR EINA_COLOR_GREEN
#define PROTOCOL_COLOR EINA_COLOR_ORANGE
#define PROTOCOL_CONN_COLOR EINA_COLOR_WHITE
#define NAME_SERVER_COLOR EINA_COLOR_WHITE


class EinaLogger {
 public:
  EinaLogger(const std::string &domain, const std::string &color,
             bool suppressLoggingInitialized = false)
  : log_domain_(unintialized_log_domain_)
  , domain_str_(domain)
  , color_(color)
  , suppressLoggingInitialized_(suppressLoggingInitialized) {
    Initialize();
  }

  explicit EinaLogger(const std::string &color)
  : log_domain_(unintialized_log_domain_)
  , domain_str_("log")
  , color_(color)
  , suppressLoggingInitialized_(false) {
    Initialize();
  }

  explicit EinaLogger(bool suppressLoggingInitialized = true)
  : log_domain_(unintialized_log_domain_)
  , domain_str_("log")
  , color_(EINA_LOGGER_COLOR)
  , suppressLoggingInitialized_(suppressLoggingInitialized) {
    Initialize();
  }

  explicit EinaLogger(const EinaLogger &other)
  : log_domain_(unintialized_log_domain_)
  , domain_str_(other.domain_str_)
  , color_(other.color_)
  , suppressLoggingInitialized_(other.suppressLoggingInitialized_) {
    Initialize();
  }

  virtual ~EinaLogger() {
    Deinitialize();
  }

  int log_domain() const;

  std::string domain_str() const;

  void set_domain_str(const std::string &value);

  std::string color() const;

  void set_color(const std::string &value);

  static std::string Demangle(const std::string &symbol);

 protected:
  static const int unintialized_log_domain_ = -1;

  int log_domain_;
  std::string domain_str_;
  std::string color_;
  bool suppressLoggingInitialized_;

  void Initialize();
  void Deinitialize();
};

#endif  // INCLUDE_EINA_LOGGER_H_

