/*! @file thread_loop.h
 *  @brief Loop in a separate thread.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#ifndef SRC_LIB_COMMON_THREAD_LOOP_H_
#define SRC_LIB_COMMON_THREAD_LOOP_H_

#include <thread>
#include <mutex>
#include <functional>

/// @class This is the implementation of a loop in separate thread.
/// @brief Loop starts to execute in constructor and finishes in destructor.
class ThreadLoop {
 public:
  ThreadLoop(const std::function<bool(void)> &loop,
             const std::chrono::microseconds &interval =
               std::chrono::microseconds::zero());
  ~ThreadLoop();

  std::chrono::microseconds timeout();
  void stop();
 private:
  bool cancel_;
  std::thread *thread_;
  std::function<bool(void)> loop_;
  std::timed_mutex mutex_;
  std::chrono::microseconds interval_;
};

#endif  // SRC_LIB_COMMON_THREAD_LOOP_H_

