/*! @file thread_loop.cc
 *  @brief Loop in a separate thread.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "src/lib/common/thread_loop.h"

ThreadLoop::ThreadLoop(const std::function<bool(void)> &loop,
                          const std::chrono::microseconds &interval)
: cancel_(false)
, loop_(loop)
, interval_(interval) {
  thread_ = new std::thread([&]() {
    if (interval_ != std::chrono::microseconds::zero()) {
      while (!cancel_) {
        mutex_.lock();
        mutex_.try_lock_for(interval_);
        mutex_.unlock();
        if (!loop_()) break;
      }
    } else {
      while (!cancel_) {
        if (!loop_()) break;
      }
    }
  });
}

ThreadLoop::~ThreadLoop() {
  if (!cancel_) {
    stop();
  }
  delete thread_;
}

std::chrono::microseconds ThreadLoop::timeout() {
  return interval_;
}

void ThreadLoop::stop() {
  cancel_ = true;
  mutex_.unlock();
  thread_->join();
}

