/*! @file dbus_interface.h
 *  @brief Classes to provide DBus low-level API for DBusDuplex.
 *  @author Moiseenko Andrey <moiseenko.a@samsung.com>, Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#ifndef SRC_LIB_COMMON_DBUS_INTERFACE_H_
#define SRC_LIB_COMMON_DBUS_INTERFACE_H_


#include <string.h>
#include <assert.h>
#include <glibmm/variant.h>
#include <type_traits>
#include <unordered_map>
#include <memory>
#include <functional>
#include <vector>
#include <utility>
#include <string>
#include <sstream>
#include "extern_libs/Loki/TypeManip.h"
#include "include/eina_logger.h"

namespace Conference {

std::string GetObjectPath(const std::string &path);

/// @brief Unboxes the value pointer enclosed in a Glib::VariantContainerBase
/// instance.
/// @param vcb The Glib::VariantContainerBase instance containing the value.
/// @return The first child in the container casted to the passed pointer type.
template <class T>
T *GetPtrResult(const Glib::VariantContainerBase &vcb) {
#if __WORDSIZE == 64
  Glib::Variant<gint64> res;
#else
  Glib::Variant<gint32> res;
#endif
  vcb.get_child(res, 0);
  return reinterpret_cast<T *>(res.get());
}

/// @brief Unboxes the value enclosed in a Glib::VariantContainerBase instance.
/// @param vcb The Glib::VariantContainerBase instance containing the value.
/// @return The first child in the container casted to the passed type.
template <class T>
T GetResult(const Glib::VariantContainerBase &vcb) {
  Glib::Variant<T> res;
  vcb.get_child(res, 0);
  return res.get();
}

struct BaseCallback;

/// @class IntrospectionBuilder
/// @brief This class makes the D-Bus introspection XML\
/// interface description from the supplied function signatures.
class IntrospectionBuilder
: public EinaLogger {
  template <unsigned index, typename... TList> struct TypeIterator;

  // This is needed for empty args
  template <typename... Dummy>
  struct TypeIterator<-1, Dummy...> {
    TypeIterator(IntrospectionBuilder *builder __attribute__((unused)),
                 unsigned count __attribute__((unused))) {}

    void Iterate() {}
  };

  template <class Head>
  struct TypeIterator<0, Head> {
    IntrospectionBuilder *builder_;
    unsigned count_;

    TypeIterator(IntrospectionBuilder *builder, unsigned count)
    : builder_(builder), count_(count) {}

    void Iterate() {
      builder_->xml_ << "<arg name=\"arg" << count_ << "\" type=\"";
      builder_->xml_ << builder_->ArgToIntrospectionXml<Head>();
      builder_->xml_ << "\" />" << std::endl;
    }
  };

  template <unsigned i, class Head, typename... Tail>
  struct TypeIterator<i, Head, Tail...> {
    static_assert(i == sizeof...(Tail), "Type index is out of bounds");

    IntrospectionBuilder *builder_;
    unsigned count_;

    TypeIterator(IntrospectionBuilder *builder, unsigned count)
    : builder_(builder), count_(count) {}

    void Iterate() {
      builder_->xml_ << "<arg name=\"arg" << count_ - i << "\" type=\"";
      builder_->xml_ << builder_->ArgToIntrospectionXml<Head>();
      builder_->xml_ << "\" />" << std::endl;
      TypeIterator<i - 1, Tail...> res(builder_, count_);
      res.Iterate();
    }
  };
  template <typename... Tail>
  struct HeadIterator;
  template < class Head, typename... Tail>
  struct HeadIterator<Head, Tail...> {
    IntrospectionBuilder *builder_;
    unsigned count_;

    HeadIterator(IntrospectionBuilder *builder, unsigned count)
    : builder_(builder), count_(count) {}

    void Iterate() {
      const char *returnArg = builder_->ArgToIntrospectionXml<Head>();
      if (returnArg != nullptr) {
        builder_->xml_ << "<arg name=\"arg" << 1 << "\" type=\"";
        builder_->xml_ << *returnArg;
        builder_->xml_ << "\" direction=\"out\" />" << std::endl;
      }
      TypeIterator<sizeof...(Tail) - 1, Tail...> res(builder_, count_);
      res.Iterate();
    }
  };

  std::stringstream xml_;
  std::string name_;
 public:
  explicit IntrospectionBuilder(const std::string &interfaceName);

  std::string Build() const;

  std::string name() const {
    return name_;
  }

  operator std::string() const {
    return Build();
  }

  template<typename... Args>
  IntrospectionBuilder &AddMethod(const std::string &name) {
    xml_ << "<method name=\"" << name << "\">" << std::endl;
    HeadIterator<Args...> iterator(this, sizeof...(Args));
    iterator.Iterate();
    xml_ << "</method>" << std::endl;
    return *this;
  }

  template<class T>
  static const char *ArgToIntrospectionXml() {
    if (std::is_pointer<T>::value) {
      #if __WORDSIZE == 64
        return "x";
      #else
        return "i";
      #endif
    }
    if (std::is_same<T, void>::value) return nullptr;
    if (std::is_enum<T>::value) return "i";
    if (std::is_same<T, std::string>::value) return "ay";
    assert(std::is_arithmetic<T>::value &&
           "Only passing basic types by value is supported");
    if (std::is_same<T, uint8_t>::value ||
        std::is_same<T, int8_t>::value) return "y";
    if (std::is_same<T, uint16_t>::value) return "q";
    if (std::is_same<T, uint32_t>::value) return "u";
    if (std::is_same<T, uint64_t>::value) return "t";
    return typeid(T).name();
  }
};

template<typename... Args>
Glib::VariantContainerBase PackIntoVariantContainer(Args... i_data) {
  std::vector<Glib::VariantBase > v;
  typedef typename TypeAt<0, Args...>::Result ParamType;
  Loki::Int2Type<std::is_pointer<ParamType>::value? 1
      : std::is_enum<ParamType>::value? 2
        : 0> variantTypeNumber;
  v = vector_pack_into_variant_container(variantTypeNumber, v, i_data ...);
  return Glib::VariantContainerBase::create_tuple(v);
}

// vector_pack_into_variant_container

inline std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<0>&,
    std::vector<Glib::VariantBase >&v) {
  return v;
}

inline std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    std::vector<Glib::VariantBase >&v) {
  return v;
}

template<class T>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<0>&,
    std::vector<Glib::VariantBase >&v,
    T i_data) {
  v.push_back(Glib::Variant<T>::create(i_data));
  return vector_pack_into_variant_container(v);
}

template<class T>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<1>&,
    std::vector<Glib::VariantBase >&v,
    T i_data) {
  #if __WORDSIZE == 64
  v.push_back(Glib::Variant<gint64>::create(reinterpret_cast<gint64>(i_data)));
  #else
  v.push_back(Glib::Variant<gint32>::create(reinterpret_cast<gint32>(i_data)));
  #endif
  return vector_pack_into_variant_container(v);
}

template<class T>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<2>&,
    std::vector<Glib::VariantBase >&v,
    T i_data) {
  v.push_back(Glib::Variant<gint32>::create(static_cast<gint32>(i_data)));
  return vector_pack_into_variant_container(v);
}

// Forward declarations begin
template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<0>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other);

template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<1>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other);

template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<2>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other);
// Forward declarations end

template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<0>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other) {
  v.push_back(Glib::Variant<T>::create(i_data));
  typedef typename TypeAt<0, Args...>::Result ParamType;
  Loki::Int2Type<std::is_pointer<ParamType>::value? 1
      : std::is_enum<ParamType>::value? 2
        : 0> variantTypeNumber;
  return vector_pack_into_variant_container(variantTypeNumber, v, other...);
}

template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<1>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other) {
  #if __WORDSIZE == 64
  v.push_back(Glib::Variant<gint64>::create(reinterpret_cast<gint64>(i_data)));
  #else
  v.push_back(Glib::Variant<gint32>::create(reinterpret_cast<gint32>(i_data)));
  #endif
  typedef typename TypeAt<0, Args...>::Result ParamType;
  Loki::Int2Type<std::is_pointer<ParamType>::value? 1
      : std::is_enum<ParamType>::value? 2
        : 0> variantTypeNumber;
  return vector_pack_into_variant_container(variantTypeNumber, v, other...);
}

template<class T, typename... Args>
std::vector<Glib::VariantBase > &vector_pack_into_variant_container(
    const Loki::Int2Type<2>&,
    std::vector<Glib::VariantBase >&v,
    T i_data,
    Args... other) {
  v.push_back(Glib::Variant<gint32>::create(static_cast<gint32>(i_data)));

  typedef typename TypeAt<0, Args...>::Result ParamType;
  Loki::Int2Type<std::is_pointer<ParamType>::value? 1
      : std::is_enum<ParamType>::value? 2
        : 0> variantTypeNumber;
  return vector_pack_into_variant_container(variantTypeNumber, v, other...);
}

template<typename ReturnValue, typename... Args>
class Unpacker {
  ReturnValue callback_entry(const Glib::VariantContainerBase &i_data) const {
    int size = i_data.get_n_children();
    static const int S = sizeof...(Args);
    assert(S == size);
    Loki::Int2Type<S> index;

    typedef typename
    TypeAt<(S - 1) >= 0? (S - 1) : 0, Args...>::Result NextParamType;
    Loki::Int2Type<(S - 1) >= 0? std::is_pointer<NextParamType>::value? 1
                                 : std::is_enum<NextParamType>::value? 2
                                   : 0
                               : 0> variantTypeNumber;
    return callback_recursive(index, variantTypeNumber, i_data);
  }

  template<int N, typename... IArgs>
  ReturnValue callback_recursive(Loki::Int2Type<N>, const Loki::Int2Type<0> &,
                         const Glib::VariantContainerBase &i_data,
                         IArgs... data) const {
    static const int S = (sizeof...(Args) - sizeof...(IArgs)) - 1;
    typedef typename TypeAt<S, Args...>::Result ParamType;
    Glib::Variant<ParamType> p;
    i_data.get_child(p, S);
    ParamType ip = p.get();
    Loki::Int2Type<S> index;

    typedef typename
    TypeAt<(S - 1) >= 0? (S - 1) : 0, Args...>::Result NextParamType;
    Loki::Int2Type<(S - 1) >= 0? std::is_pointer<NextParamType>::value? 1
                                 : std::is_enum<NextParamType>::value? 2
                                   : 0
                               : 0> variantTypeNumber;
    return callback_recursive(index, variantTypeNumber, i_data, ip, data...);
  }

  template<int N, typename... IArgs>
  ReturnValue callback_recursive(Loki::Int2Type<N>, const Loki::Int2Type<1> &,
                         const Glib::VariantContainerBase &i_data,
                         IArgs... data) const {
    static const int S = (sizeof...(Args) - sizeof...(IArgs)) - 1;
    typedef typename TypeAt<S, Args...>::Result ParamType;
    #if __WORDSIZE == 64
    Glib::Variant<gint64> p;
    #else
    Glib::Variant<gint32> p;
    #endif
    i_data.get_child(p, S);
    ParamType ip = reinterpret_cast<ParamType>(p.get());
    Loki::Int2Type<S> index;

    typedef typename
    TypeAt<(S - 1) >= 0? (S - 1) : 0, Args...>::Result NextParamType;
    Loki::Int2Type<(S - 1) >= 0? std::is_pointer<NextParamType>::value? 1
                                 : std::is_enum<NextParamType>::value? 2
                                   : 0
                               : 0> variantTypeNumber;
    return callback_recursive(index, variantTypeNumber, i_data, ip, data...);
  }

  template<int N, typename... IArgs>
  ReturnValue callback_recursive(Loki::Int2Type<N>, const Loki::Int2Type<2> &,
                         const Glib::VariantContainerBase &i_data,
                         IArgs... data) const {
    static const int S = (sizeof...(Args) - sizeof...(IArgs)) - 1;
    typedef typename TypeAt<S, Args...>::Result ParamType;
    Glib::Variant<gint32> p;
    i_data.get_child(p, S);
    ParamType ip = static_cast<ParamType>(p.get());
    Loki::Int2Type<S> index;

    typedef typename
    TypeAt<(S - 1) >= 0? (S - 1) : 0, Args...>::Result NextParamType;
    Loki::Int2Type<(S - 1) >= 0? std::is_pointer<NextParamType>::value? 1
                                 : std::is_enum<NextParamType>::value? 2
                                   : 0
                               : 0> variantTypeNumber;
    return callback_recursive(index, variantTypeNumber, i_data, ip, data...);
  }

  template<typename... IArgs>
  ReturnValue callback_recursive(Loki::Int2Type<0>, const Loki::Int2Type<0> &,
                         const Glib::VariantContainerBase &i_data
                         __attribute__((unused)),
                         IArgs... data) const {
    return WrappedFunction(data...);
  }

  std::function<ReturnValue(Args...)> WrappedFunction;

 public:
  Unpacker(const std::function<ReturnValue(Args...)> &f)
  : WrappedFunction(f) {}
  Unpacker(const Unpacker &i_other)
  : WrappedFunction(i_other.WrappedFunction) {}
  virtual ~Unpacker() {}
  ReturnValue operator()(
      const Glib::VariantContainerBase &i_data) const {
    return callback_entry(i_data);
  }
  Unpacker &operator=(const Unpacker &i_other) {
    WrappedFunction = i_other.WrappedFunction;
    return *this;
  }
};

class BaseCallback {
 public:
  virtual Glib::VariantContainerBase operator()(
      const Glib::VariantContainerBase &i_data) const = 0;
  virtual BaseCallback* clone() const = 0;
  virtual void add_description(IntrospectionBuilder *io_description,
                               const char* name) = 0;
  virtual std::string signature() const = 0;
  virtual ~BaseCallback() {}

 protected:
  template <unsigned index, typename... TList> struct SignatureIterator;

  // This is needed for empty args
  template <typename... Dummy>
  struct SignatureIterator<-1, Dummy...> {
    SignatureIterator(std::stringstream *str
                      __attribute__((unused))) {}

    void Iterate() {}
  };

  template <class Head>
  struct SignatureIterator<0, Head> {
    std::stringstream *str_;

    explicit SignatureIterator(std::stringstream *str)
    : str_(str) {}

    void Iterate() {
      (*str_) << IntrospectionBuilder::ArgToIntrospectionXml<Head>();
    }
  };

  template <unsigned i, class Head, typename... Tail>
  struct SignatureIterator<i, Head, Tail...> {
    static_assert(i == sizeof...(Tail), "Type index is out of bounds");

    std::stringstream *str_;

    explicit SignatureIterator(std::stringstream *str)
    : str_(str) {}

    void Iterate() {
      (*str_) << IntrospectionBuilder::ArgToIntrospectionXml<Head>();
      SignatureIterator<i - 1, Tail...> res(str_);
      res.Iterate();
    }
  };
};

template<typename ReturnType, typename... Args>
class Callback: public BaseCallback, private Unpacker<ReturnType, Args...> {
 public:
  Callback(std::function<ReturnType(Args...)> &&f
           = std::function<ReturnType(Args...)>())
  : Unpacker<ReturnType, Args...>(f) {}
  Callback(const Callback &i_other): Unpacker<ReturnType, Args...>(i_other) {}
  Glib::VariantContainerBase operator()(
      const Glib::VariantContainerBase &i_data) const {
    return PackIntoVariantContainer(
        this->Unpacker<ReturnType, Args...>::operator()(i_data));
  }

  BaseCallback* clone() const {
    return new Callback(*this);
  }

  void add_description(IntrospectionBuilder *io_description,
                       const char* name) {
    io_description->AddMethod<ReturnType, Args...>(name);
  }

  std::string signature() const {
    std::stringstream ss;
    ss << "(";
    SignatureIterator<sizeof...(Args) - 1, Args...> res(&ss);
    res.Iterate();
    ss << ")";
    return ss.str();
  }
};

template<typename... Args>
class Callback<void, Args...>
: public BaseCallback, private Unpacker<void, Args...> {
 public:
  Callback(std::function<void(Args...)> &&f = std::function<void(Args...)>())
  : Unpacker<void, Args...>(f) {}
  Callback(const Callback &i_other): Unpacker<void, Args...>(i_other) {}
  Glib::VariantContainerBase operator()(
      const Glib::VariantContainerBase &i_data) const {
    this->Unpacker<void, Args...>::operator()(i_data);
    return Glib::VariantContainerBase();
  }

  BaseCallback* clone() const {
    return new Callback(*this);
  }

  void add_description(IntrospectionBuilder *io_description,
                       const char* name) {
    io_description->AddMethod<void, Args...>(name);
  }

  std::string signature() const {
    std::stringstream ss;
    ss << "(";
    SignatureIterator<sizeof...(Args) - 1, Args...> res(&ss);
    res.Iterate();
    ss << ")";
    return ss.str();
  }
};

class InterfaceException {};
class UnknownMethodException: public InterfaceException {};

/// @brief The description of a D-Bus interface which can be passed into
/// the DBusDuplex constructor.
class DBusInterface: protected IntrospectionBuilder {
 public:
  typedef std::shared_ptr<BaseCallback> SpBaseCallback;
  typedef std::unordered_map<std::string, SpBaseCallback> HandlerMethods;

 public:
    explicit DBusInterface(const std::string &interfaceName)
    : IntrospectionBuilder(interfaceName) {}

    explicit DBusInterface(const DBusInterface &other);

    virtual ~DBusInterface() {}
    const BaseCallback &operator[](std::string i_method) const;

    /// @brief Adds a handler of a function invocation under the specified name.
    /// @param i_name The function name.
    /// @param i_fun The functor which will be called.
    /// @return Reference to this class instance.
    DBusInterface &AddHandler(const std::string &i_name,
                              const BaseCallback &i_fun);

    std::string description() const {
      return this->Build();
    }

    std::string name() const {
      return this->IntrospectionBuilder::name();
    }

 private:
    HandlerMethods functions_;

    DBusInterface &AddHandlerInternal(const std::string &i_name,
                                      const BaseCallback &i_fun);
};
}  // namespace Conference

#endif  // SRC_LIB_COMMON_DBUS_INTERFACE_H_

