/*! @file dbus_duplex.cc
 *  @brief DBus duplex connection implementation.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include "src/lib/common/dbus_duplex.h"
#include <algorithm>

namespace Conference {

bool GioObject::gioIsInitialized = false;

std::mutex GioObject::mutex_;

GioObject::GioObject() {
  std::lock_guard<std::mutex> lock(mutex_);
  if (!gioIsInitialized) {
    Gio::init();
    gioIsInitialized = true;
  }
}

DBusDuplex::DBusDuplex(const DBusInterface &interface)
: EinaLogger("dbus_" + interface.name(),
             DBUSDUPLEX_LOG_COLOR)
, parameters_(interface, on_method_call)
, is_registered_(false)
, failed_to_register_(false)
, activeCalls_(0) {
  // Prepare the introspection data
  std::string ixml = parameters_.interface_.description();
  std::string path = parameters_.interface_.name();
  parameters_.path_ = path.c_str();
  GError *gerror = nullptr;
  parameters_.introspection_data_ = std::shared_ptr<GDBusNodeInfo>(
      g_dbus_node_info_new_for_xml(ixml.c_str(), &gerror),
      std::ptr_fun(g_dbus_node_info_unref));
  if (gerror != nullptr) {
    ERR("Caught an instance of the Glib::Error exception: %s",
        gerror->message);
    Glib::Error::throw_exception(gerror);
  }

  // Acquire the connection asynchronously
  g_bus_get(G_BUS_TYPE_SESSION, nullptr, on_bus_acquired, this);
}

DBusDuplex::~DBusDuplex() {
  if (is_registered_) {
    // Ensure that all D-Bus outgoing calls are dispatched
    DBG("g_dbus_connection_flush_sync()");
    GError *gerror = nullptr;
    g_dbus_connection_flush_sync(parameters_.connection_, nullptr, &gerror);
    if (gerror != nullptr) {
      ERR("Caught an instance of the Glib::Error exception: %s",
          gerror->message);
      Glib::Error::throw_exception(gerror);
    }
    // Unregister the interface
    DBG("g_dbus_connection_unregister_object(), id = %d",
        parameters_.registered_id_);
    g_dbus_connection_unregister_object(parameters_.connection_,
                                        parameters_.registered_id_);
    parameters_.registered_id_ = 0;
    // Ensure that all D-Bus async calls are completed
    Wait();
    // Poison this instance while destroying
    failed_to_register_ = true;
    is_registered_ = false;
    // Unregister the name
    DBG("g_bus_unown_name(\"%s\")", parameters_.interface_.name().c_str());
    g_bus_unown_name(parameters_.name_id_);
    parameters_.name_id_ = 0;
    // We should wait until on_name_lost is fired here...
    // But it never does. So just believe in the shiny future.
  }
}

bool DBusDuplex::WaitForRegistration() {
  if (!failed_to_register_ && !is_registered_) {
    blocker_.lock();
    if (!failed_to_register_ && !is_registered_) {
      assert(!g_main_context_is_owner(g_main_context_default()) &&
             "Shooting yourself in the foot");
      DBG("Blocked until the registration is complete");
      blocker_.lock();
      blocker_.unlock();
    }
    if (is_registered_) {
      INF("Registered in D-Bus");
    } else {
      assert(failed_to_register_);
      ERR("Failed to register in D-Bus");
    }
  }
  return is_registered_;
}

DBusDuplex &DBusDuplex::AddPeer(int id, const std::string &dbusPath) {
  Glib::RefPtr<Gio::DBus::Connection> connection =
    Gio::DBus::Connection::get_sync(Gio::DBus::BUS_TYPE_SESSION);
  assert(connection && "Failed to get the connection to "
         "Gio::DBus::BUS_TYPE_SESSION");
  DBG("name = \"%s\", object_path=\"%s\", "
      "interface_name=\"%s\"", dbusPath.c_str(),
      GetObjectPath(dbusPath).c_str(),
      dbusPath.c_str());
  assert(g_dbus_is_name(dbusPath.c_str()) &&
         "The specified D-Bus path is invalid");
  if (peers_.find(id) != peers_.end()) {
    DBG("Appending \"%s\" to peer ID %d", dbusPath.c_str(), id);
  }
  Glib::RefPtr<Gio::DBus::Proxy> proxy;
  if (proxyCache_.find(dbusPath) != proxyCache_.end()) {
    DBG("Cache hit");
    proxy = proxyCache_[dbusPath];
  } else {
    DBG("Cache miss, create_sync()");
    proxy = Gio::DBus::Proxy::create_sync(connection,
                                          dbusPath,
                                          GetObjectPath(dbusPath).c_str(),
                                          dbusPath);
    if (!proxy) {
      ERR("Failed to create_sync()");
      // TODO(v.markovtsev): handle this error
    }
    proxyCache_.insert(std::make_pair(dbusPath, proxy));
  }
  peers_[id].push_back(proxy);
  return *this;
}

DBusDuplex &DBusDuplex::AddPeer(int id,
                                std::initializer_list<const char *>dbusPaths) {
  assert(dbusPaths.size() > 0 &&"Need at least one D-Bus path");
  Glib::RefPtr<Gio::DBus::Connection> connection =
    Gio::DBus::Connection::get_sync(Gio::DBus::BUS_TYPE_SESSION);
  assert(connection && "Failed to get the connection to "
         "Gio::DBus::BUS_TYPE_SESSION");
  if (peers_.find(id) != peers_.end()) {
    DBG("Appending to peer ID %d", id);
  }
  for (auto dbusPath = dbusPaths.begin(); dbusPath != dbusPaths.end();
      ++dbusPath) {
    std::string objectPath(GetObjectPath(*dbusPath));
    DBG("name = \"%s\", object_path=\"%s\", "
        "interface_name=\"%s\"", *dbusPath, objectPath.c_str(),
        *dbusPath);
    assert(g_dbus_is_name(*dbusPath) && "The specified D-Bus path is invalid");
    Glib::RefPtr<Gio::DBus::Proxy> proxy;
    if (proxyCache_.find(*dbusPath) != proxyCache_.end()) {
      DBG("Cache hit");
      proxy = proxyCache_[*dbusPath];
    } else {
      DBG("Cache miss, create_sync()");
      proxy = Gio::DBus::Proxy::create_sync(connection,
                                            *dbusPath,
                                            objectPath.c_str(),
                                            *dbusPath);
      if (!proxy) {
        ERR("Failed to create_sync()");
        // TODO(v.markovtsev): handle this error
      }
      proxyCache_.insert(std::make_pair(*dbusPath, proxy));
    }
    peers_[id].push_back(proxy);
  }
  return *this;
}

void DBusDuplex::Wait() {
  assert(is_registered_ && "Not registered in D-Bus");
  if (activeCalls_ > 0) {
    blocker_.lock();
    if (activeCalls_ == 0) {
      blocker_.unlock();
    } else {
      DBG("Blocked (%i active calls)", activeCalls_.load());
      blocker_.lock();
      blocker_.unlock();
      DBG("Resumed");
    }
  }
}

void DBusDuplex::on_async_ready(GObject *source_object
                                __attribute__((unused)),
                                GAsyncResult *res,
                                gpointer user_data) {
  assert(user_data);
  auto acp = reinterpret_cast<AsyncCallParameters *>(user_data);
  auto self = acp->self;
  // Free the call parameters
  g_variant_unref(acp->callArgs);
  delete acp;

  GError *error = nullptr;
  auto resultVariant = g_dbus_proxy_call_finish(
      reinterpret_cast<GDBusProxy *>(source_object), res, &error);
  if (error != nullptr) {
    ERRI(self, "Caught an instance of the Glib::Error exception: %s",
        error->message);
    Glib::Error::throw_exception(error);
  }
  {
    std::lock_guard<std::mutex> lock(self->asyncResultMutex_);
    self->asyncResult_ = Glib::VariantContainerBase(resultVariant);
  }
  int localCalls = --self->activeCalls_;
  if (localCalls == 0) {
    self->blocker_.unlock();
  }
  DBGI(self, "%i pending active calls",
       localCalls);
}

void DBusDuplex::on_bus_acquired(GObject *source_object
                                 __attribute__((unused)),
                                 GAsyncResult *res,
                                 gpointer selfptr) {
  assert(selfptr);
  auto self = reinterpret_cast<DBusDuplex *>(selfptr);
  assert(!self->failed_to_register_ && "DbusDuplex has already been destroyed");

  // Get the connection
  GError *gerror = nullptr;
  self->parameters_.connection_ = g_bus_get_finish(res, &gerror);
  if (gerror != nullptr) {
    ERRI(self, "Caught an instance of the Glib::Error exception: %s.",
         gerror->message);
    self->failed_to_register_ = true;
    self->blocker_.unlock();
    Glib::Error::throw_exception(gerror);
  }

  auto objectPath = GetObjectPath(self->parameters_.path_);
  DBGI(self, "name = \"%s\", object_path = \"%s\", connection = %p",
       self->parameters_.interface_.name().c_str(), objectPath.c_str(),
       self->parameters_.connection_);

  gerror = nullptr;
  self->parameters_.registered_id_ =
      g_dbus_connection_register_object(self->parameters_.connection_,
          objectPath.c_str(),
          self->parameters_.introspection_data_->interfaces[0],
          &self->parameters_.interface_vtable_,
          self, nullptr, &gerror);
  if (gerror != nullptr) {
    ERRI(self, "Caught an instance of the Glib::Error exception: %s.",
         gerror->message);
    self->failed_to_register_ = true;
    self->blocker_.unlock();
    Glib::Error::throw_exception(gerror);
  }
  DBGI(self, "Registered object id = %d",
       self->parameters_.registered_id_);

  DBGI(self, "g_bus_own_name_on_connection(), path = \"%s\"",
       self->parameters_.path_);
  self->parameters_.name_id_ = g_bus_own_name_on_connection(
      self->parameters_.connection_,
      self->parameters_.path_,
      G_BUS_NAME_OWNER_FLAGS_NONE,
      on_name_acquired,
      on_name_lost,
      self, nullptr);
}

void DBusDuplex::on_name_acquired(GDBusConnection *connection
                                  __attribute__((unused)),
                                  const gchar *name,
                                  gpointer selfptr) {
  assert(selfptr);
  auto self = reinterpret_cast<DBusDuplex *>(selfptr);
  DBGI(self, "name = \"%s\"", name);
  self->is_registered_ = true;
  self->blocker_.unlock();
}

void DBusDuplex::on_name_lost(GDBusConnection *connection,
                              const gchar *name,
                              gpointer selfptr) {
  assert(selfptr);
  auto self = reinterpret_cast<DBusDuplex *>(selfptr);
  self->is_registered_ = false;
  self->parameters_.name_id_ = 0;
  if (self->parameters_.registered_id_ > 0) {
    DBGI(self, "unregister_object(), name = \"%s\", id = %d",
         name, self->parameters_.registered_id_);
    g_dbus_connection_unregister_object(connection,
                                        self->parameters_.registered_id_);
    self->parameters_.registered_id_ = 0;
  }
}

void DBusDuplex::on_method_call(GDBusConnection *connection
                                __attribute__((unused)),
                                const gchar *sender,
                                const gchar *object_path,
                                const gchar *interface_name,
                                const gchar *method_name,
                                GVariant *parameters,
                                GDBusMethodInvocation *invocation,
                                gpointer selfptr) {
  assert(selfptr);
  auto self = reinterpret_cast<DBusDuplex *>(selfptr);
  DBGI(self,
       "\033[45m\033[37;1m%s\033[0m enter\n"
       "(sender = \"%s\", object_path = \"%s\""
       ", interface_name = \"%s\", signature = %s)",
       method_name, sender, object_path, interface_name,
       g_variant_get_type_string(parameters));
  assert(self->is_registered_ && "Not registered in D-Bus");
  Glib::VariantContainerBase result;
  try {
    result = self->parameters_
        .interface_[method_name](Glib::VariantContainerBase(parameters, true));
  } catch(const UnknownMethodException  &e) {
    Glib::Error error(G_DBUS_ERROR, Gio::DBus::Error::UNKNOWN_METHOD,
                    "The requested method is not registered");
    g_dbus_method_invocation_return_gerror(invocation, error.gobj());
    return;
  }
  g_dbus_method_invocation_return_value(invocation, result.gobj());
  DBGI(self, "\033[45m\033[37;1m%s\033[0m return", method_name);
}

void DBusDuplex::CheckPeer(int id) {
  if (peers_.find(id) == peers_.end()) {
    ERR("Could not find the peer %d", id);
    // TODO(v.markovtsev): throw exception here
  }
}

}  // namespace Conference

