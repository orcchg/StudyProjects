/*! @file dbus_interface.cc
 *  @brief Tests related to dbus_interface.cc.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */


#include "tests/google/gtest/gtest.h"
#include "src/lib/common/dbus_interface.h"

using namespace Conference;

TEST(IntrospectionBuilder, AddMethod) {
  IntrospectionBuilder builder("com.samsung.Tester");
  builder.AddMethod<gint64, gint16, gint32>("Method1");
  builder.AddMethod<const char *, IntrospectionBuilder *>("Method2");
  auto xml = builder.Build();

  std::string origin("<!DOCTYPE node PUBLIC "
"\"-//freedesktop//DTD D-BUS Object Introspection 1.0//EN\"\n"
"\"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd\">\n"
"<node name=\"/com/samsung/Tester\">\n"
"<interface name=\"com.samsung.Tester\">\n"
"<method name=\"Method1\">\n"
"<arg name=\"arg1\" type=\"x\" direction=\"out\" />\n"
"<arg name=\"arg2\" type=\"s\" />\n"
"<arg name=\"arg3\" type=\"i\" />\n"
"</method>\n"
"<method name=\"Method2\">\n"
"<arg name=\"arg1\" type=\"i\" direction=\"out\" />\n"
"<arg name=\"arg2\" type=\"i\" />\n"
"</method>\n"
"</interface>\n"
"</node>");

  ASSERT_STREQ(xml.c_str(), origin.c_str());
}

enum TestEnum {
  kFirst,
  kSecond
};

TEST(PackIntoVariantContainer, Self) {
  int p1 = 10;
  double p2 = 3.14159;
  const char *p3 = "string";
  std::string p4(p3);
  auto p5 = kSecond;
  auto container = PackIntoVariantContainer(p1, p2, p3, &p4, p4, p5);
  ASSERT_EQ(container.get_n_children(), 6);
  {
    Glib::Variant<int> vp1;
    container.get_child(vp1, 0);
    ASSERT_EQ(vp1.get(), 10);
  }
  {
    Glib::Variant<double> vp2;
    container.get_child(vp2, 1);
    ASSERT_EQ(vp2.get(), 3.14159);
  }
  {
#if __WORDSIZE == 64
    Glib::Variant<gint64> vp3;
#else
    Glib::Variant<gint32> vp3;
#endif
    container.get_child(vp3, 2);
    const char *str = reinterpret_cast<char *>(vp3.get());
    ASSERT_STREQ(str, "string");
  }
  {
#if __WORDSIZE == 64
    Glib::Variant<gint64> vp4;
#else
    Glib::Variant<gint32> vp4;
#endif
    container.get_child(vp4, 3);
    std::string *str = reinterpret_cast<std::string *>(vp4.get());
    ASSERT_STREQ(str->c_str(), "string");
  }
  {
    Glib::Variant<std::string> vp5;
    container.get_child(vp5, 4);
    ASSERT_STREQ(vp5.get().c_str(), "string");
  }
  {
    Glib::Variant<gint32> vp6;
    container.get_child(vp6, 5);
    ASSERT_EQ(static_cast<TestEnum>(vp6.get()), kSecond);
  }
}

bool UnpackerTestFunc(int p1, const char *p2, double p3, int *res) {
  *res = (p1 == 10 && !strcmp(p2, "string") && p3 == 3.14159)  * 10;
  return *res;
}

bool UnpackerTestFuncValue = false;

void UnpackerTrivialTestFunc() {
  UnpackerTestFuncValue = true;
}

void UnpackerEnumTestFunc(TestEnum value) {
  UnpackerTestFuncValue = (value == kSecond? true : false);
}

TEST(Unpacker, Call) {
  bool res = false;
  auto container = PackIntoVariantContainer(10, "string", 3.14159, &res);
  Unpacker<bool, int, const char *, double, int *> up(UnpackerTestFunc);
  bool res2 = up(container);
  ASSERT_EQ(res, 10);
  ASSERT_TRUE(res2);
}

TEST(Unpacker, TrivialCall) {
  auto container = PackIntoVariantContainer();
  Unpacker<void> up(UnpackerTrivialTestFunc);
  up(container);
  ASSERT_TRUE(UnpackerTestFuncValue);
}

TEST(Unpacker, EnumCall) {
  auto te = kSecond;
  auto container = PackIntoVariantContainer(te);
  Unpacker<void, TestEnum> up(UnpackerEnumTestFunc);
  up(container);
  ASSERT_TRUE(UnpackerTestFuncValue);
}

// TODO(v.markovtsev): more tests here

#include "tests/google/src/gtest_main.cc"

