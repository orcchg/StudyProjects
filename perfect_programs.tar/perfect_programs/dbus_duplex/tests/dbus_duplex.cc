/*! @file dbus_duplex.cc
 *  @brief Tests for DBusDuplex.
 *  @author Moiseenko Andrey <moiseenko.a@samsung.com>, Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include <thread>
#include <atomic>
#include <random>
#include <algorithm>
#include <functional>
#include "tests/google/gtest/gtest.h"
#include "src/lib/common/dbus_duplex.h"

using Conference::DBusDuplex;
using Conference::DBusInterface;
using Conference::Callback;
using Conference::GetResult;

enum StringTypes {
  kStringTypeBad,
  kStringTypeGood
};

class MyPeer1 {
 public:
  std::unique_ptr<DBusDuplex> duplex;
  int Step;
  bool Fail;
  int ChkSum;

  void IntMethod(int x) {
    Step += x;
  }

  void UnsignedMethod(void* /*ptr*/,
                      unsigned val) {
    ChkSum = val;
  }

  int ReturnMethod(std::string str, std::string *strptr, StringTypes type) {
    if (type == kStringTypeGood && str == *strptr) {
      return str.size();
    } else {
      return 0;
    }
  }

  void SerialMethod(int x) {
    if (Step == x - 1) {
      Step = x;
    } else {
      Fail = true;
    }
  }

  void CriticalMethod() {
    if (critical_) {
      Fail = true;
    }
    critical_ = true;
    auto myrand = std::bind(std::uniform_real_distribution<>(),
                          std::mt19937());
    Step = myrand();
    Step /= 7;
    Step += 5;
    if (Step > 1000) {
      Step = (std::sqrt(Step) * 3 + 101) / 1.5;
    } else {
      Step = (std::sqrt(Step) * 3.1 + 102) / 1.55;
    }
    critical_ = false;
  }

  void ComplexMethod(int flag, const void *buffer, guint bufferLength) {
    ChkSum = CalcChkSum(buffer, bufferLength) + flag;
  }

  static int CalcChkSum(const void *buffer, guint bufferLength) {
    int res = 0;
    auto chbuf = reinterpret_cast<const char *>(buffer);
    for (guint i = 0; i < bufferLength; i++) {
      res ^= chbuf[i];
    }
    return res;
  }

  MyPeer1()
  : Step(0)
  , Fail(false)
  , ChkSum(0)
  , critical_(false) {
    DBusInterface interface("com.samsung.MyPeer1");
    interface.AddHandler("IntMethod",
                         Callback<void, int>(
                           std::bind(&MyPeer1::IntMethod,
                                     this, std::placeholders::_1)))
             .AddHandler("UnsignedMethod",
                         Callback<void, void *, unsigned>(
                           std::bind(&MyPeer1::UnsignedMethod,
                                     this, std::placeholders::_1,
                                     std::placeholders::_2)))
             .AddHandler("ReturnMethod",
                         Callback<int, std::string, std::string *, StringTypes>(
                           std::bind(&MyPeer1::ReturnMethod,
                                     this, std::placeholders::_1,
                                     std::placeholders::_2,
                                     std::placeholders::_3)))
             .AddHandler("CriticalMethod",
                         Callback<void>(
                           std::bind(&MyPeer1::CriticalMethod,
                                     this)))
             .AddHandler("SerialMethod",
                         Callback<void, int>(
                           std::bind(&MyPeer1::SerialMethod,
                                     this, std::placeholders::_1)))
             .AddHandler("ComplexMethod",
                         Callback<void, int, const void *, guint>(
                           std::bind(&MyPeer1::ComplexMethod,
                                     this, std::placeholders::_1,
                                     std::placeholders::_2,
                                     std::placeholders::_3)));
    duplex = std::unique_ptr<DBusDuplex>(new DBusDuplex(interface));
  }

 private:
  std::atomic<bool> critical_;
};

class MyPeer2 {
 public:
  std::unique_ptr<DBusDuplex> duplex;
  int Step;

  void IntMethod(int x) {
    Step += x;
  }

  MyPeer2()
  : Step(0) {
    DBusInterface interface("com.samsung.MyPeer2");
    interface.AddHandler("IntMethod",
                         Callback<void, int>(
                           std::bind(&MyPeer2::IntMethod,
                                     this, std::placeholders::_1)));
    duplex = std::unique_ptr<DBusDuplex>(new DBusDuplex(interface));
  }
};

TEST(DBusDuplex, CallAndWait) {
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  {
    MyPeer1 peer1;
    MyPeer2 peer2;
    peer1.duplex->AddPeer(1, "com.samsung.MyPeer2");
    peer2.duplex->AddPeer(1, "com.samsung.MyPeer1");

    peer1.duplex->WaitForRegistration();
    peer2.duplex->WaitForRegistration();

    for (int i = 0; i < 10; ++i) {
       peer1.duplex->CallAndWait(1, "IntMethod", 1);
       ASSERT_EQ(i + 1, peer2.Step);
       peer2.duplex->CallAndWait(1, "IntMethod", 1);
       ASSERT_EQ(i + 1, peer1.Step);
    }

    std::string str("abcdefghijklmnopqrstuvwxyz");
    int chksum = MyPeer1::CalcChkSum(str.c_str(), str.size()) + 1;
    peer2.duplex->CallAndWait(1, "ComplexMethod", 1, str.c_str(), str.size());
    ASSERT_EQ(chksum, peer1.ChkSum);
  }

  loop->quit();
  main.join();
}

TEST(DBusDuplex, CallAndWaitExoticTypes) {
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  {
    MyPeer1 peer1;
    MyPeer2 peer2;
    peer1.duplex->AddPeer(1, "com.samsung.MyPeer2");
    peer2.duplex->AddPeer(1, "com.samsung.MyPeer1");

    peer1.duplex->WaitForRegistration();
    peer2.duplex->WaitForRegistration();

    peer2.duplex->CallAndWait(
        1,
        "UnsignedMethod",
        reinterpret_cast<void *>(0),
        static_cast<unsigned>(11));
    ASSERT_EQ(11, peer1.ChkSum);
    peer2.duplex->CallAndWait(
        1,
        "UnsignedMethod",
        reinterpret_cast<void *>(0),
        static_cast<unsigned>(29));
    ASSERT_EQ(29, peer1.ChkSum);
    peer2.duplex->Call(
        1,
        "UnsignedMethod",
        reinterpret_cast<void *>(0),
        static_cast<unsigned>(11));
    peer2.duplex->Call(
        1,
        "UnsignedMethod",
        reinterpret_cast<void *>(0),
        static_cast<unsigned>(29));
    peer2.duplex->Wait();
    ASSERT_EQ(29, peer1.ChkSum);
  }

  loop->quit();
  main.join();
}

TEST(DBusDuplex, Call) {
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  {
    MyPeer1 peer1;
    MyPeer2 peer2;
    peer1.duplex->AddPeer(1, "com.samsung.MyPeer2");
    peer2.duplex->AddPeer(1, "com.samsung.MyPeer1");

    peer1.duplex->WaitForRegistration();
    peer2.duplex->WaitForRegistration();

    for (int i = 0; i < 10; ++i) {
       peer1.duplex->Call(1, "IntMethod", 1);
       peer2.duplex->Call(1, "IntMethod", 1);
    }
    peer1.duplex->Wait();
    peer2.duplex->Wait();
    ASSERT_EQ(10, peer1.Step);
    ASSERT_EQ(10, peer2.Step);
  }

  loop->quit();
  main.join();
}

TEST(DBusDuplex, CallAndWaitValue) {
  MyPeer1 peer1;
  MyPeer2 peer2;
  peer1.duplex->AddPeer(1, "com.samsung.MyPeer2");
  peer2.duplex->AddPeer(1, "com.samsung.MyPeer1");

  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  peer1.duplex->WaitForRegistration();
  peer2.duplex->WaitForRegistration();

  std::string str("string");
  auto res = peer2.duplex-> CallAndWait(
      1, "ReturnMethod", str, &str, kStringTypeGood)[0];
  EXPECT_EQ(GetResult<int>(res), str.size());
  loop->quit();
  main.join();
}

TEST(DBusDuplex, CallValue) {
  MyPeer1 peer1;
  MyPeer2 peer2;
  peer1.duplex->AddPeer(1, "com.samsung.MyPeer2");
  peer2.duplex->AddPeer(1, "com.samsung.MyPeer1");

  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  peer1.duplex->WaitForRegistration();
  peer2.duplex->WaitForRegistration();

  std::string str("string");
  peer2.duplex->Call(1, "ReturnMethod", str, &str, kStringTypeGood);
  peer2.duplex->Wait();
  auto res = peer2.duplex->LastResult<int>();
  EXPECT_EQ(res, str.size());
  loop->quit();
  main.join();
}

TEST(DBusDuplex, DuplicatePeers) {
  MyPeer1 peer1;
  MyPeer2 peer2;
  peer1.duplex->AddPeer(1, { "com.samsung.MyPeer2", "com.samsung.MyPeer2" });

  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });

  peer1.duplex->WaitForRegistration();
  peer2.duplex->WaitForRegistration();

  peer1.duplex->CallAndWait(1, "IntMethod", 1);
  EXPECT_EQ(2, peer2.Step);
  loop->quit();
  main.join();
}

TEST(DBusDuplex, Inception) {
  MyPeer1 peer1;
  peer1.duplex->AddPeer(1, "com.samsung.MyPeer1");
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });
  peer1.duplex->WaitForRegistration();
  peer1.duplex->CallAndWait(1, "IntMethod", 10);
  ASSERT_EQ(10, peer1.Step);
  loop->quit();
  main.join();
}

TEST(DBusDuplex, Critical) {
  MyPeer1 peer1;
  peer1.duplex->AddPeer(1, "com.samsung.MyPeer1");
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });
  peer1.duplex->WaitForRegistration();

  std::thread t1([&]() {
    for (int i = 0; i < 100; i++) {
      peer1.duplex->Call(1, "CriticalMethod");
    }
  });
  std::thread t2([&]() {
    for (int i = 0; i < 100; i++) {
      peer1.duplex->Call(1, "CriticalMethod");
    }
  });
  std::thread t3([&]() {
    for (int i = 0; i < 100; i++) {
      peer1.duplex->Call(1, "CriticalMethod");
    }
  });
  t1.join();
  t2.join();
  t3.join();
  peer1.duplex->Wait();
  EXPECT_FALSE(peer1.Fail);
  loop->quit();
  main.join();
}

TEST(DBusDuplex, Serial) {
  MyPeer1 peer1;
  peer1.duplex->AddPeer(1, "com.samsung.MyPeer1");
  auto loop = Glib::MainLoop::create();
  std::thread main([&]() {
    loop->run();
  });
  peer1.duplex->WaitForRegistration();

  for (int i = 0; i < 100; i++) {
    peer1.duplex->Call(1, "SerialMethod", i + 1);
  }
  peer1.duplex->Wait();
  EXPECT_FALSE(peer1.Fail);
  loop->quit();
  main.join();
}

TEST(DBusDuplex, Duplicates) {
  MyPeer1 peer1;
  MyPeer1 peer2;
  auto loop = Glib::MainLoop::create();
  bool exception = false;
  std::thread main([&]() {
    try {
      loop->run();
    }
    catch(const Glib::Error &e) {
      exception = true;
    }
  });
  main.join();
  EXPECT_TRUE(exception);
}

#include "tests/google/src/gtest_main.cc"

