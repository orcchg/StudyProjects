/*! @file interface.cc
 *  @brief Classes to provide DBus low-level API for DBusDuplex.
 *  @author Moiseenko Andrey <moiseenko.a@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */


#include "src/lib/common/dbus_interface.h"
#include <algorithm>

namespace Conference {

std::string GetObjectPath(const std::string &path) {
  std::string objectPath("/" + path);
  std::replace(objectPath.begin(), objectPath.end(), '.', '/');
  return objectPath;
}

IntrospectionBuilder::IntrospectionBuilder(const std::string &interfaceName)
: EinaLogger("IntrospectionBuilder", INTROSPECTION_BUILDER_COLOR, true)
, name_(interfaceName) {
  xml_ << "<!DOCTYPE node PUBLIC "
      "\"-//freedesktop//DTD D-BUS Object Introspection 1.0//EN\"";
  xml_ << std::endl;
  xml_ << "\"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd\">";
  xml_ << std::endl;
  xml_ << "<node name=\"" << GetObjectPath(name_) << "\">" << std::endl;
  xml_ << "<interface name=\"" << name_ << "\">" << std::endl;
}

std::string IntrospectionBuilder::Build() const {
  std::string res(xml_.str());
  res.append("</interface>");
  res.append("\n");
  res.append("</node>");
  DBG("Interface name is \"%s\".\nThe resulting introspection XML is:\n%s",
      name().c_str(),
      res.c_str());
  return res;
}

DBusInterface::DBusInterface(const DBusInterface &other)
: IntrospectionBuilder(other.name()) {
  for (auto I = other.functions_.begin();
      I != other.functions_.end(); ++I) {
    AddHandlerInternal(I->first, *I->second);
  }
}

const BaseCallback &DBusInterface::operator[](std::string i_method) const {
  auto function = functions_.find(i_method);
  if (function == functions_.end()) {
     throw UnknownMethodException();
  }
  return *(function->second);
}

DBusInterface &DBusInterface::AddHandlerInternal(const std::string &i_name,
                                  const BaseCallback &i_fun) {
  SpBaseCallback p(i_fun.clone());
  p->add_description(this, i_name.c_str());
  functions_.insert(std::pair<std::string, SpBaseCallback&>(i_name, p));
  return *this;
}

DBusInterface &DBusInterface::AddHandler(const std::string &i_name,
                                         const BaseCallback &i_fun) {
  DBG("Added handler %s%s", i_name.c_str(), i_fun.signature().c_str());
  return AddHandlerInternal(i_name, i_fun);
}

}  // namespace conference

