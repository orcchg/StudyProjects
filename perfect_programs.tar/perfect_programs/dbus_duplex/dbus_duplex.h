/*! @file dbus_duplex.h
 *  @brief DBus duplex connection implementation.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>, Moiseenko Andrey <moiseenko.a@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 *
 *  @section Usage
 *  #define PEER_MASTER 1
 *
 *  class Foo {
 *   public:
 *    void MyMethod(int x, std::string y) {
 *      std::cout <<  x << y << std::endl;
 *    }
 *
 *    int OtherMethod() {
 *      return 7;
 *    }
 *
 *    Foo() {
 *      DBusInterface interface("com.samsung.vconf.Foo");
 *      interface.AddHandler("MyMethod", Callback<void, int, std::string>(
 *                           std::bind(&Foo::MyMethod,
 *                                     this,
 *                                     std::placeholders::_1,
 *                                     std::placeholders::_2)))
 *               .AddHandler("OtherMethod", Callback<void>(
 *                           std::bind(&Foo::OtherMethod,
 *                                     this)));
 *      duplex_ = std::unique_ptr<DBusDuplex>(new DBusDuplex(interface));
 *      duplex_.AddPeer(PEER_MASTER, "com.samsung.vconf.Master");
 *    }
 *   private:
 *    std::unique_ptr<DBusDuplex> duplex_;
 *
 *    void MyLogic() {
 *      duplex_->Call(PEER_MASTER, "MasterMethod", "hello");
 *    }
 *  };
 *
 *  ...
 *
 *  void Master::MyMethodOnFoo() {
 *    duplex->Call(PEER_FOO, "MyMethod", 2, std::string("master"));
 *  }
 */

#ifndef SRC_LIB_COMMON_DBUS_DUPLEX_H_
#define SRC_LIB_COMMON_DBUS_DUPLEX_H_

#include <giomm.h>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <memory>
#include <string>
#include <vector>
#include "include/eina_logger.h"
#include "src/lib/common/dbus_interface.h"

namespace Conference {

class GioObject {
 private:
  static bool gioIsInitialized;
  static std::mutex mutex_;
 public:
  GioObject();
};

typedef  void (*on_method_call_func_type)(
    const Glib::RefPtr<Gio::DBus::Connection>&,
    const Glib::ustring&, const Glib::ustring&,
    const Glib::ustring&, const Glib::ustring&,
    const Glib::VariantContainerBase&,
    const Glib::RefPtr<Gio::DBus::MethodInvocation>&);

struct DBusServerParameters {
  guint name_id_;
  guint registered_id_;
  GDBusConnection *connection_;
  std::shared_ptr<GDBusNodeInfo> introspection_data_;
  GDBusInterfaceVTable interface_vtable_;
  const char *path_;
  DBusInterface interface_;

  explicit DBusServerParameters(const DBusInterface &interface,
                                GDBusInterfaceMethodCallFunc on_method_call)
  : name_id_(0)
  , registered_id_(0)
  , connection_(nullptr)
  , path_(nullptr)
  , interface_(interface) {
    interface_vtable_.method_call = on_method_call;
  }
};

/// @brief Implementation of the thread-safe methods invocation using D-Bus
/// as the backend. This class hides all the D-Bus setup complexity from the
/// user and provides a simple interface. It takes an instance of DBusInterface
/// to initialize. To enable calling functions from remote peers one must
/// execute AddPeer(). Then, Call/CallAndWait become accessible.
/// @note Remember that there always should be a running Glib main loop
/// to make everything work. It is a good idea to ensure the complete D-Bus
/// registration with WaitForRegistration() before actually using the
/// class functionality.
class DBusDuplex
: public EinaLogger
, public GioObject {
 public:
  /// @brief Initializes a new instance of the DBusDuplex class.
  /// @param interface The D-Bus interface description.
  explicit DBusDuplex(const DBusInterface &interface);

  virtual ~DBusDuplex();

  /// @brief Blocks the calling thread until the D-Bus registration started
  /// asynchronously in the class constructor is complete.
  /// @return True if registration was successfull; otherwise, false.
  /// @note Usually, when the registration fails, an exception is thrown
  /// in the Glib main loop context.
  bool WaitForRegistration();

  /// @brief Adds the specified D-Bus path as a possible callee.
  /// @param id The remote peer id (set to any unique integer you like).
  /// @param dbusPath Path
  /// @return Reference to this class instance.
  DBusDuplex &AddPeer(int id, const std::string &dbusPath);

  /// @brief Adds the variable length list of D-Bus paths as a single callee.
  /// @param id The remote peer id (set to any unique integer you like).
  /// @param dbusPaths the list of strings corresponding to D-Bus paths.
  /// @note This overridden method allows to invoke callbacks in
  /// a broadcast way.
  /// @return Reference to this class instance.
  DBusDuplex &AddPeer(int id, std::initializer_list<const char *> dbusPaths);

  /// @brief Invokes a remote function asynchronously.
  /// @param id The remote peer id (the same as passed in AddPeer()).
  /// @param name The function name.
  /// @param args The arbitrary set of function arguments.
  template<typename... Args>
  void Call(int id, const std::string &name,
            Args... args) {
    assert(is_registered_ && "Not registered in D-Bus");
    CheckPeer(id);
    auto packedParameters = PackIntoVariantContainer(args...);
    if (peers_[id].size() > 1) {
      DBG("\033[35;1m%s\033[0m\n(id = %d, args count is %d, "
          "peers count is %d)",
          name.c_str(), id, sizeof...(Args), peers_[id].size());
    } else {
      DBG("\033[35;1m%s\033[0m @%s%s", name.c_str(),
          peers_[id][0]->get_name().c_str(),
          g_variant_get_type_string(packedParameters.gobj()));
    }
    for (auto ptr = peers_[id].begin(); ptr != peers_[id].end(); ++ptr) {
      activeCalls_++;
      if (peers_[id].size() > 1) {
        DBG("Calling %s%s", (*ptr)->get_name().c_str(),
            g_variant_get_type_string(packedParameters.gobj()));
      }
      auto userData = new AsyncCallParameters { this, packedParameters.gobj() };
      g_dbus_proxy_call((*ptr)->gobj(), name.c_str(),
                        // Ensure that this variant will not be disposed
                        // on next iteration / loop exit
                        packedParameters.gobj_copy(),
                        G_DBUS_CALL_FLAGS_NONE, -1,
                        nullptr, on_async_ready, userData);
    }
  }

  /// @brief Blocks the calling thread until there are no more active
  /// asynchronous invocations started with Call().
  /// @note The last invocation result can be obtained with LastResult().
  void Wait();

  /// @brief Invokes a remote function synchronously.
  /// @param id The remote peer id (the same as passed in AddPeer()).
  /// @param name The function name.
  /// @param args The arbitrary set of function arguments.
  /// @return The std::vector instance containing the result for
  /// each peer path. Usually, AddPeer() is called with a single D-Bus path,
  /// so this vector contains the single value. It can be unboxed with
  /// GetResult().
  template<typename... Args>
  std::vector<Glib::VariantContainerBase> CallAndWait(int id,
                                                      const std::string &name,
                                                      Args... args) {
    assert(is_registered_ && "Not registered in D-Bus");
    assert(!g_main_context_is_owner(g_main_context_default()) &&
           "Shooting yourself in the foot");
    CheckPeer(id);
    auto packedParameters = PackIntoVariantContainer(args...);
    if (peers_[id].size() > 1) {
      DBG("\033[35;1m%s\033[0m\n(id = %d, args count is %d, "
          "peers count is %d)",
          name.c_str(), id, sizeof...(Args), peers_[id].size());
    } else {
      DBG("\033[35;1m%s\033[0m @%s%s", name.c_str(),
          peers_[id][0]->get_name().c_str(),
          g_variant_get_type_string(packedParameters.gobj()));
    }
    std::vector<Glib::VariantContainerBase> results;
    for (auto ptr = peers_[id].begin(); ptr != peers_[id].end(); ++ptr) {
      try {
        if (peers_[id].size() > 1) {
          DBG("Calling %s%s", (*ptr)->get_name().c_str(),
              g_variant_get_type_string(packedParameters.gobj()));
        }
        auto res = (*ptr)->call_sync(name.c_str(), packedParameters);
        results.push_back(res);
      }
      catch(const Glib::Error &e) {
        ERR("Caught an instance of the Glib::Error exception: %s",
            e.what().c_str());
        throw e;
      }
    }
    return results;
  }

  /// @brief Returns the last result from the invocation performed with Call().
  template <class T>
  T LastResult() {
    assert(is_registered_ && "Not registered in D-Bus");
    std::lock_guard<std::mutex> lock(asyncResultMutex_);
    return GetResult<T>(asyncResult_);
  }

 private:
  struct AsyncCallParameters {
    DBusDuplex *self;
    GVariant *callArgs;
  };

  DBusServerParameters parameters_;
  std::unordered_map<int, std::vector<Glib::RefPtr<Gio::DBus::Proxy> > > peers_;
  std::unordered_map<std::string, Glib::RefPtr<Gio::DBus::Proxy> > proxyCache_;
  std::mutex blocker_;
  std::mutex asyncResultMutex_;
  std::atomic<bool> is_registered_;
  std::atomic<bool> failed_to_register_;
  std::atomic<int> activeCalls_;
  Glib::VariantContainerBase asyncResult_;

  static void on_async_ready(GObject *source_object,
                             GAsyncResult *res,
                             gpointer selfptr);

  static void on_bus_acquired(GObject *source_object,
                              GAsyncResult *res,
                              gpointer selfptr);

  static void on_name_acquired(GDBusConnection *connection,
                               const gchar *name,
                               gpointer selfptr);

  static void on_name_lost(
      GDBusConnection *connection,
      const gchar *name,
      gpointer selfptr);

  static void on_method_call(GDBusConnection       *connection,
                             const gchar           *sender,
                             const gchar           *object_path,
                             const gchar           *interface_name,
                             const gchar           *method_name,
                             GVariant              *parameters,
                             GDBusMethodInvocation *invocation,
                             gpointer               selfptr);

  /// @brief Checks whether the specified peer identifier is valid.
  void CheckPeer(int id);
};

}  // namespace Conference
#endif  // SRC_LIB_COMMON_DBUS_DUPLEX_H_

