/*! @file zlib_unbuffered.cc
 *  @brief Implementation of the fast compression/decompression with Zlib.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */



#include "src/lib/common/zlib_unbuffered.h"
#include <assert.h>
#include <zlib.h>
#include "include/common.h"

namespace Zlib {

float compress_unbuffered(const void *inData, size_t inDataSize,
                         std::vector<char> *outData) {
  assert(outData != nullptr);

  z_stream strm;
  strm.zalloc = 0;
  strm.zfree = 0;
  strm.opaque = 0;
  strm.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(inData));
  strm.avail_in = inDataSize;

  deflateInit(&strm, Z_BEST_COMPRESSION);
  int bound = deflateBound(&strm, inDataSize);
  outData->resize(bound);
  strm.next_out = reinterpret_cast<Bytef *>(&(*outData)[0]);
  strm.avail_out = bound;

  int res = deflate(&strm, Z_FINISH);
  assert(res == Z_STREAM_END);
  res = deflateEnd(&strm);
  assert(res == Z_OK);

  outData->resize(strm.total_out);
  return (strm.total_out + .0f) / inDataSize;
}

void decompress_unbuffered(const void *inData, size_t inDataSize,
                           std::vector<char> *outData) {
  assert(outData != nullptr);

  z_stream strm;
  strm.zalloc = 0;
  strm.zfree = 0;
  strm.opaque = 0;
  strm.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(inData));
  strm.avail_in = inDataSize;
  strm.next_out = reinterpret_cast<Bytef *>(&(*outData)[0]);
  strm.avail_out = outData->size();

  inflateInit(&strm);
  int res = inflate(&strm, Z_FINISH);
  assert(res == Z_STREAM_END);
  res = inflateEnd(&strm);
  assert(res == Z_OK);
}

}  // namespace Zlib

