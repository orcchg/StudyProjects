/*! @file zlib_unbuffered.h
 *  @brief Efficient compression/decompression with Zlib.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */



#ifndef SRC_LIB_COMMON_ZLIB_UNBUFFERED_H_
#define SRC_LIB_COMMON_ZLIB_UNBUFFERED_H_

#include <stddef.h>
#include <vector>

namespace Zlib {

float compress_unbuffered(const void *inData, size_t inDataSize,
                          std::vector<char> *outData);

void decompress_unbuffered(const void *inData, size_t inDataSize,
                           std::vector<char> *outData);

}  // namespace Zlib

#endif  // SRC_LIB_COMMON_ZLIB_UNBUFFERED_H_

