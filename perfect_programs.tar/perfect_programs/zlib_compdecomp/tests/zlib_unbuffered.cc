/*! @file zlib_unbuffered.cc
 *  @brief Tests for zlib_unbuffered compression/decompression.
 *  @author Markovtsev Vadim <v.markovtsev@samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>.
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#include <string.h>
#include <zlib.h>
#include "src/lib/common/zlib_unbuffered.h"
#include "tests/google/gtest/gtest.h"

const char data[] = "Как известно, для нормальной работы большинство софта "
    "должно быть не только скомпилировано, но и правильно установлено в "
    "системе. Программы ожидают найти нужные им файлы в определённых местах,"
    " и места эти в большинстве *nix-систем зашиты в код на этапе компиляции."
    " Помимо этого аспекта основным отличием процесса установки в "
    "linux/freebsd/whatever от таковой в Windows и MacOS является то, что "
    "программа не просто складывает кучу файлов в отдельную директорию в "
    "Program Files или /Applications, а «размазывает» себя по всей файловой "
    "системе. Библиотеки идут в lib, исполняемые файлы в bin, конфиги в etc, "
    "разного рода данные в var и так далее. Если вам вдруг понадобится её "
    "обновить, то всё это надо сначала как-то вычистить, т. к. при "
    "использовании новой версии остатки файлов от старой могут привести к "
    "совершенно непредсказуемым последствиям, зачастую нехорошим. "
    "Вероятность этого события не так велика, но оно вам надо на "
    "боевом сервере?";

TEST(Zlib, compress_unbuffered) {
  std::vector<char> compressed;
  Zlib::compress_unbuffered(data, sizeof(data), &compressed);
  auto dest = new Bytef[sizeof(data)];
  uLongf len = sizeof(data);
  uncompress(dest, &len, reinterpret_cast<Bytef *>(&compressed[0]),
             compressed.size());
  ASSERT_EQ(len, sizeof(data));
  ASSERT_EQ(memcmp(data, dest, sizeof(data)), 0);
  delete[] dest;
}

TEST(Zlib, decompress_unbuffered) {
  auto dest = new Bytef[sizeof(data)];
  uLongf len = sizeof(data);
  compress(dest, &len,
           const_cast<Bytef *>(reinterpret_cast<const Bytef *>(data)),
           sizeof(data));
  std::vector<char> original(sizeof(data));
  Zlib::decompress_unbuffered(dest, len, &original);
  ASSERT_EQ(original.size(), sizeof(data));
  ASSERT_EQ(memcmp(data, &original[0], sizeof(data)), 0);
}

TEST(Zlib, compress_decompress) {
  std::vector<char> compressed;
  Zlib::compress_unbuffered(data, sizeof(data), &compressed);
  std::vector<char> original(sizeof(data));
  Zlib::decompress_unbuffered(&compressed[0], compressed.size(), &original);
  ASSERT_EQ(original.size(), sizeof(data));
  ASSERT_EQ(memcmp(data, &original[0], sizeof(data)), 0);
}

#include "tests/google/src/gtest_main.cc"

