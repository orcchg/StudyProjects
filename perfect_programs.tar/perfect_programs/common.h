/*! @file common.h
 *  @brief Common header included into all source files.
 *  @author Markovtsev Vadim <v.markovtsev.samsung.com>
 *  @version 1.0
 *
 *  @section Notes
 *  This code conforms to <a href="http://google-styleguide.googlecode.com/svn/trunk/cppguide.xml">Google C++ Style Guide</a>
 *
 *  @section Copyright
 *  Copyright 2012 Samsung Electronics
 */

#ifndef INCLUDE_COMMON_H_
#define INCLUDE_COMMON_H_

#include <mutex>
#include <string>
#include "./config.h"

#if __GNUC__ == 4 && __GNUC_MINOR__ < 6
#define nullptr NULL
#endif

template <unsigned index, typename... TList> struct TypeAt;

template <>
struct TypeAt<0> {
    typedef void Result;
};

template <class Head, typename... Tail>
struct TypeAt<0, Head, Tail...> {
    typedef Head Result;
};

template <unsigned i, class Head, typename... Tail>
struct TypeAt<i, Head, Tail...> {
  static_assert(i <= sizeof...(Tail) , "Type index is out of bounds");

  typedef typename TypeAt<i - 1, Tail...>::Result Result;
};

template<class InstanceClass>
class Singleton {
 public:
  Singleton(const Singleton&) = delete;
  Singleton(Singleton&&) = delete;
  Singleton& operator = (const Singleton&) = delete;
  Singleton&& operator = (Singleton&&) = delete;
  static InstanceClass &instance() {
    static InstanceClass inst;
    return inst;
  }
  virtual ~Singleton() {}
 protected:
#if __GNUC__ == 4 && __GNUC_MINOR__ < 6
  Singleton() {}
#else
  Singleton() = default;
#endif
};

#if __WORDSIZE == 64
#define POINT2INT_CAST(a)\
    reinterpret_cast<int64>(a)
#else
#define POINT2INT_CAST(a)\
    reinterpret_cast<int>(a)
#endif

#endif  // INCLUDE_COMMON_H_

